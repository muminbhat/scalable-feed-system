/**
 * @file
 * 
 * @brief Old SAX version 1 handler, deprecated
 * 
 * @deprecated set of SAX version 1 interfaces used to
 *              build the DOM tree.
 *
 * @copyright See Copyright for the status of this software.
 *
 * @author Daniel Veillard
 */

#ifndef __XML_SAX_H__
#define __XML_SAX_H__

#ifdef __GNUC__
  #warning "libxml/SAX.h is deprecated"
#endif

#endif /* __XML_SAX_H__ */
